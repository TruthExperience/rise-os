import { NextResponse } from "next/server";
import { createClient, createAdminClient } from "@/lib/supabaseServer";

export async function GET() {
  const admin = createAdminClient();

  const { data: leagues, error } = await admin
    .schema("pitboss")
    .from("leagues")
    .select("id, name, slug, sport, logo_url")
    .eq("is_public", true)
    .eq("pitboss_status", "active")
    .order("name");

  if (error) {
    return NextResponse.json({ error: error.message }, { status: 500 });
  }

  let joinedLeagueIds: string[] = [];

  const supabase = await createClient();
  const {
    data: { user },
  } = await supabase.auth.getUser();

  if (user) {
    const { data: profile } = await admin
      .from("users")
      .select("id")
      .eq("auth_user_id", user.id)
      .maybeSingle();

    const { data: driver } = profile
      ? await admin
          .schema("pitboss")
          .from("drivers")
          .select("id")
          .eq("user_id", profile.id)
          .maybeSingle()
      : { data: null };

    if (driver) {
      const { data: rows } = await admin
        .schema("pitboss")
        .from("driver_leagues")
        .select("league_id")
        .eq("driver_id", driver.id);
      joinedLeagueIds = (rows ?? []).map((r) => r.league_id);
    }
  }

  return NextResponse.json({
    leagues: (leagues ?? []).map((l) => ({
      ...l,
      isMember: joinedLeagueIds.includes(l.id),
    })),
  });
}
