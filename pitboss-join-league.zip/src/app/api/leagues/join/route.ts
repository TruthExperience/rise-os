import { NextRequest, NextResponse } from "next/server";
import { createClient } from "@/lib/supabaseServer";

export async function POST(req: NextRequest) {
  const supabase = await createClient();

  const {
    data: { user },
  } = await supabase.auth.getUser();

  if (!user) {
    return NextResponse.json({ error: "Not signed in" }, { status: 401 });
  }

  const { leagueId } = await req.json();
  if (!leagueId) {
    return NextResponse.json({ error: "leagueId is required" }, { status: 400 });
  }

  // No p_user_id here on purpose — join_league() derives the caller from
  // auth.uid() itself, so this call can only ever join a league as you.
  const { data, error } = await supabase
    .schema("pitboss")
    .rpc("join_league", { p_league_id: leagueId });

  if (error) {
    const status =
      error.code === "42501" ? 403 : error.code === "P0002" ? 404 : error.code === "28000" ? 401 : 500;
    return NextResponse.json({ error: error.message }, { status });
  }

  return NextResponse.json({ driverLeague: data });
}
